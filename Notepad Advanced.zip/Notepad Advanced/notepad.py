#import tkinter

import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter import font,colorchooser,filedialog,messagebox
import os

#window formation
main_application = tk.Tk()
main_application.geometry("1200x600")
main_application.title("Speak with Me")
#main_application.wm_iconbitmap('icon.ico')

main_menu = tk.Menu()

#File menu icons
new_icon = tk.PhotoImage(file = "icon/new.png")
open_icon = tk.PhotoImage(file = "icon/open.png")
save_icon = tk.PhotoImage(file = "icon/save.png")
save_as_icon = tk.PhotoImage(file = "icon/saveas.png")
exit_icon = tk.PhotoImage(file = "icon/exit.png")

#Edit menu icons
copy_icon = tk.PhotoImage(file = "icon/copy.png")
paste_icon = tk.PhotoImage(file = "icon/paste.png")
cut_icon = tk.PhotoImage(file = "icon/cut.png")
clear_all_icon = tk.PhotoImage(file = "icon/clearall.png")
find_icon = tk.PhotoImage(file = "icon/find.png")

#View menu icons
toolbar_icon = tk.PhotoImage(file = "icon/toolbar.png")
statusbar_icon = tk.PhotoImage(file = "icon/statusbar.png")

#theme menu icons
light_default_icon = tk.PhotoImage(file='icon/lightdefault.png')
light_plus_icon = tk.PhotoImage(file='icon/lightplus.png')
dark_icon = tk.PhotoImage(file='icon/dark.png')
red_icon = tk.PhotoImage(file='icon/red.png')
monokai_icon = tk.PhotoImage(file='icon/monokai.png')
night_blue_icon = tk.PhotoImage(file='icon/nightblue.png')
color_theme = tk.Menu(main_menu, tearoff=False)

theme_choice = tk.StringVar()
color_icons = (light_default_icon, light_plus_icon, dark_icon, red_icon, monokai_icon, night_blue_icon)

color_dict = {
    'Light Default ' : ('#000000', '#ffffff'),
    'Light Plus' : ('#474747', '#e0e0e0'),
    'Dark' : ('#c4c4c4', '#2d2d2d'),
    'Red' : ('#2d2d2d', '#ffe8e8'),
    'Monokai' : ('#d3b774', '#474747'),
    'Night Blue' :('#ededed', '#6b9dc2')
}

#making menubar
file = tk.Menu(main_menu,tearoff=False)
main_menu.add_cascade(label = "File",menu=file)

edit = tk.Menu(main_menu,tearoff=False)
main_menu.add_cascade(label = "Edit",menu=edit)

view = tk.Menu(main_menu,tearoff=False)
main_menu.add_cascade(label = "View",menu=view)

color_theme = tk.Menu(main_menu,tearoff=False)
main_menu.add_cascade(label = "Theme",menu=color_theme)

#creating label
tool_bar_label = ttk.Label(main_application)
tool_bar_label.pack(side=tk.TOP,fill=tk.X)
#Font family
font_tuple=tk.font.families()
font_family=tk.StringVar()
font_box=ttk.Combobox(tool_bar_label,width=30,textvariable=font_family,state="readonly")
font_box["values"]=font_tuple
font_box.current(font_tuple.index("Arial"))
font_box.grid(row=0,column=0,padx=5,pady=5)
#Size selection
size_variable=tk.IntVar()
font_size=ttk.Combobox(tool_bar_label,width=20,textvariable=size_variable,state="readonly")
font_size["values"]=tuple(range(8,100,2))
font_size.current(4)
font_size.grid(row=0,column=1,padx=5,pady=5)
#creating Bold,Italic,Underline,colorpicker,paragraph alignments
#bold
bold_icon = tk.PhotoImage(file = "icon/bold.png")
bold_button=Button(tool_bar_label,image=bold_icon,bd=0)
bold_button.grid(row=0,column=2,padx=5,pady=5)
#italic
italic_icon = tk.PhotoImage(file = "icon/italic.png")
italic_button=Button(tool_bar_label,image=italic_icon,bd=0)
italic_button.grid(row=0,column=3,padx=5,pady=5)
#underline
u_icon = tk.PhotoImage(file = "icon/underline.png")
u_button=Button(tool_bar_label,image=u_icon,bd=0)
u_button.grid(row=0,column=4,padx=5,pady=5)
#colorpicker
cp_icon = tk.PhotoImage(file = "icon/colorwheel.png")
cp_button=Button(tool_bar_label,image=cp_icon,bd=0)
cp_button.grid(row=0,column=5,padx=5,pady=5)
#left
L_icon = tk.PhotoImage(file = "icon/leftpara.png")
L_button=ttk.Button(tool_bar_label,image=L_icon)
L_button.grid(row=0,column=6,padx=5,pady=5)
#right
C_icon = tk.PhotoImage(file = "icon/centerpara.png")
C_button=ttk.Button(tool_bar_label,image=C_icon)
C_button.grid(row=0,column=7,padx=5,pady=5)
#center
R_icon = tk.PhotoImage(file = "icon/rightpara.png")
R_button=ttk.Button(tool_bar_label,image=R_icon)
R_button.grid(row=0,column=8,padx=5,pady=5)
#speech function
def speech():
    return
#speech button
speech_icon = tk.PhotoImage(file = "icon/speech.png")
speech_button=Button(tool_bar_label,image=speech_icon,bd=0,command=speech)
speech_button.grid(row=0,column=9,padx=5,pady=5)
#def for help
def help_btn():
    box = tk.Tk()
    box.geometry("800x500")
    box.configure(bg='white')
    box.title("HELP")
    label = Label(box,text="follow these steps before using the software",bg='white')
    label.pack()
#help
help_icon = tk.PhotoImage(file = "icon/help.png")
help_button=Button(tool_bar_label,image=help_icon,bd = 0,command=help_btn)
help_button.grid(row=0,column=10)
#textBOX
text_editor=tk.Text(main_application)
text_editor.config(wrap="word",relief=tk.FLAT)

scroll_bar=tk.Scrollbar(main_application)
text_editor.focus_set()
scroll_bar.pack(side=tk.RIGHT,fill=tk.Y)
text_editor.pack(fill=tk.BOTH,expand=True)
scroll_bar.config(command=text_editor.yview)
text_editor.config(yscrollcommand=scroll_bar.set)

#making status bar
status_bars=ttk.Label(main_application,text="Status Bar")
status_bars.pack(side=tk.BOTTOM)

text_change=False

def change_word(event=None):
    global text_change
    if text_editor.edit_modified():
        text_change=True
        word = len(text_editor.get(1.0,"end-1c").split())
        character=len(text_editor.get(1.0,"end-1c").replace(" ",""))
        status_bars.config(text = "character {} word {}".format(character,word))
    text_editor.edit_modified(False)

text_editor.bind("<<Modified>>",change_word)

#working of Font assign
font_now="Arial"
font_size_now=16

def change_font(main_application):
    global font_now
    font_now=font_family.get()
    text_editor.config(font=(font_now,font_size_now))

def change_size(main_application):
    global font_size_now
    font_size_now=size_variable.get()
    text_editor.config(font=(font_now,font_size_now))

font_box.bind("<<ComboboxSelected>>",change_font)
font_size.bind("<<ComboboxSelected>>",change_size)

#working of BOLD assign

def bold_fun():
    bold_font = font.Font(text_editor,text_editor.cget("font"))
    bold_font.configure(weight="bold")

    text_editor.tag_configure("bold",font=bold_font)

    current_tags = text_editor.tag_names("sel.first")

    if "bold" in current_tags:
        text_editor.tag_remove("bold","sel.first","sel.last")
        
    else:
        text_editor.tag_add("bold","sel.first","sel.last")
        

bold_button.configure(command=bold_fun)
#working of Italic assign

def Italic_fun():
    I_font = font.Font(text_editor,text_editor.cget("font"))
    I_font.configure(slant="italic")

    text_editor.tag_configure("italic",font=I_font)

    current_tags = text_editor.tag_names("sel.first")

    if "italic" in current_tags:
        text_editor.tag_remove("italic","sel.first","sel.last")
        
    else:
        text_editor.tag_add("italic","sel.first","sel.last")
        

italic_button.configure(command=Italic_fun)

#working of Underline assign

def u_fun():
    text_get = tk.font.Font(font=text_editor["font"])
    if text_get.actual()["underline"]==0:
        text_editor.config(font=(font_now,font_size_now,"underline"))
    if text_get.actual()["underline"]==1:
        text_editor.config(font=(font_now,font_size_now,"normal"))

u_button.configure(command=u_fun)

#working of colorwheel assign

def color_choose_fun():
    color_var=tk.colorchooser.askcolor()
    text_editor.configure(fg=color_var[1])

cp_button.configure(command=color_choose_fun)

#working for text alignment LEFT,CENTER,RIGHT

def L_fun():
    text_get_all=text_editor.get(1.0,"end")
    text_editor.tag_config("left",justify=tk.LEFT)
    text_editor.delete(1.0,tk.END)
    text_editor.insert(tk.INSERT,text_get_all,"left")

L_button.configure(command=L_fun)

def C_fun():
    text_get_all=text_editor.get(1.0,"end")
    text_editor.tag_config("center",justify=tk.CENTER)
    text_editor.delete(1.0,tk.END)
    text_editor.insert(tk.INSERT,text_get_all,"center")

C_button.configure(command=C_fun)

def R_fun():
    text_get_all=text_editor.get(1.0,"end")
    text_editor.tag_config("right",justify=tk.RIGHT)
    text_editor.delete(1.0,tk.END)
    text_editor.insert(tk.INSERT,text_get_all,"right")

R_button.configure(command=R_fun)




#assign icons and sub-menus
#file

#File Options creating
#NEW FILE
text_url = ""

def new_file(event=None):
    global text_url
    text_url = ""
    text_editor.delete(1.0,tk.END)

file.add_command(label="New",image = new_icon,compound=tk.LEFT,accelerator="Ctrl+N",command=new_file)

def open_file(event=None):
    global text_url
    text_url = filedialog.askopenfilename(initialdir=os.getcwd(),title="select file",filetypes=(("Text file","*.txt"),("All files","*.*")))
    try:
        with open(text_url,"r") as for_read:
            text_editor.delete(1.0,tk.END)
            text_editor.insert(1.0,for_read.read())
    except FileNotFoundError:
        return
    except:
        return
    main_application.title(os.path.basename(text_url))
    
file.add_command(label="Open",image = open_icon,compound=tk.LEFT,accelerator="Ctrl+O",command=open_file)

def save_file(event = None):
    global text_url
    try:
        if text_url == "":
            text_url = filedialog.asksaveasfilename(defaultextension="txt",
                                                    filetypes=(("Text file","*.txt"),("All files","*.*"),('Word file', '.doc'),('pdf file', '.pdf')))
        if text_url:
            content = text_editor.get(1.0, tk.END)
            with open(text_url, "w", encoding="utf-8") as file:
                file.write(content)
    except Exception as e:
        print(e)

file.add_command(label="Save",image = save_icon,compound=tk.LEFT,accelerator="Ctrl+S",command=save_file)

def saveas_file(event=None):
    global text_url
    try:
        content=text_editor.get(1.0,tk.END)
        text_url=filedialog.asksaveasfile(mode="w",defaultextension="txt",filetypes=(("Text file","*.txt"),("All files","*.*"),('Word file', '.doc'),('pdf file', '.pdf')))
        text_url.write(content)
        text_url.close()
    except:
        return

file.add_command(label="Save As",image = save_as_icon,compound=tk.LEFT,accelerator="Ctrl+Alt+S",command = saveas_file)

def exit_file(event=None):
    global text_url,text_change
    try:
        if text_change:
            mbox = messagebox.askyesnocancel("Warning","Do you want to save this file")
            if mbox is True:
                if text_url:
                    content = text_editor.get(1.0, tk.END)
                    with open(text_url, "w", encoding="utf-8") as file:
                        file.write(content)
                        main_application.destroy()
                else:
                    content2 = str(text_editor.get(1.0,tk.END))
                    text_url=filedialog.asksaveasfile(mode="w",defaultextension="txt",filetypes=(("Text file","*.txt"),("All files","*.*"),('Word file', '.doc'),('pdf file', '.pdf')))
                    text_url.write(content2)
                    text_url.close()
                    main_application.destroy()
            elif mbox is False:
                main_application.destroy()
        else:
            main_application.destroy()
    except Exception as e:
        print(e)

file.add_command(label="Exit",image = exit_icon,compound=tk.LEFT,accelerator="Ctrl+",command=exit_file)

#edit
edit.add_command(label="Copy",image = copy_icon,compound=tk.LEFT,accelerator="Ctrl+C",command=lambda:text_editor.event_generate("<Control c>"))
edit.add_command(label="Paste",image = paste_icon,compound=tk.LEFT,accelerator="Ctrl+V",command=lambda:text_editor.event_generate("<Control v>"))
edit.add_command(label="Cut",image = cut_icon,compound=tk.LEFT,accelerator="Ctrl+X",command=lambda:text_editor.event_generate("<Control x>"))
edit.add_command(label="Clea All",image = clear_all_icon,compound=tk.LEFT,accelerator="Ctrl+Alt+X",command=lambda:text_editor.delete(1.0,tk.END))

def find_box():
    
    def find():
        word = find_input.get()
        text_editor.tag_remove("match","1.0",tk.END)
        matches = 0
        if word:
            start_pos = "1.0"
            while True:
                start_pos = text_editor.search(word,start_pos,stopindex = tk.END)
                if not start_pos:
                    break
                end_pos = f"{start_pos}+{len(word)}c"
                text_editor.tag_add("match",start_pos,end_pos)
                matches+=1
                start_pos = end_pos
                text_editor.tag_config("match",foreground = "black",background = "yellow")

    def replace():
        word = find_input.get()
        replace_text = replace_input.get()
        content = text_editor.get(1.0,tk.END)
        new_content = content.replace(word,replace_text)
        text_editor.delete(1.0,tk.END)
        text_editor.insert(1.0,new_content)

    
    findpop=tk.Toplevel()
    findpop.geometry("450x200")
    findpop.title("Find")
    findpop.resizable(0,0)

    find_frame=ttk.LabelFrame(findpop,text = "Find and Replace Word")
    find_frame.pack(pady=20)

    text_find = ttk.Label(find_frame,text = "Find")
    text_replace = ttk.Label(find_frame,text = "Replace")

    find_input = ttk.Entry(find_frame,width = 30)
    replace_input = ttk.Entry(find_frame,width = 30)

    find_btn = ttk.Button(find_frame,text="Find",command=find)
    replace_btn = ttk.Button(find_frame,text="Replace",command=replace)

    text_find.grid(row = 0,column = 0,padx = 4,pady = 4)
    text_replace.grid(row = 1,column = 0,padx = 4,pady = 4)

    find_input.grid(row = 0,column = 1,padx = 4,pady = 4)
    replace_input.grid(row = 1,column = 1,padx = 4,pady = 4)

    find_btn.grid(row = 2,column = 0,padx = 8,pady = 4)
    replace_btn.grid(row = 2,column = 1,padx = 8,pady = 4)

edit.add_command(label="Find",image = find_icon,compound=tk.LEFT,accelerator="Ctrl+F",command=find_box)


#view

show_status_bar = tk.BooleanVar()
show_status_bar.set(True)
show_tool_bar = tk.BooleanVar()
show_tool_bar.set(True)

def hide_toolbar():
    global show_tool_bar
    if show_tool_bar:
        tool_bar_label.pack_forget()
        show_tool_bar = False
    else:
        text_editor.pack_forget()
        status_bars.pack_forget()
        tool_bar_label.pack(side=tk.TOP,fill=tk.X)
        text_editor.pack(fill=tk.BOTH,expand=True)
        status_bars.pack(side=tk.BOTTOM)
        show_tool_bar = True


view.add_checkbutton(label="Tool Bar",onvalue=True,offvalue=0,variable=show_tool_bar,image = toolbar_icon,compound=tk.LEFT,command=hide_toolbar)

def hide_statusbar():
    global show_status_bar
    if show_status_bar:
        status_bars.pack_forget()
        show_status_bar = False
    else:
        status_bars.pack(side=tk.BOTTOM)
        show_status_bar = True

view.add_checkbutton(label="Status Bar",onvalue=True,offvalue=0,variable=show_status_bar,image = statusbar_icon,compound=tk.LEFT,command=hide_statusbar)


#theme


def change_theme():
    chosen_theme = theme_choice.get()
    color_tuple = color_dict.get(chosen_theme)
    fg_color, bg_color = color_tuple[0], color_tuple[1]
    text_editor.config(background=bg_color, fg=fg_color)


count = 0
for i in color_dict:
    color_theme.add_radiobutton(label=i,image=color_icons[count],variable=theme_choice,compound=tk.LEFT,command=change_theme)
    count+=1


    
    
    
 
main_application.config(menu=main_menu)


main_application.mainloop()
