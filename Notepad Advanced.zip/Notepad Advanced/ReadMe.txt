******************************************************************************************Read Me******************************************************************************************
1.you can directly run notepad.py or go to IDLE shell for execution.
2.you need python 3.8.5 version for this project.

enjoy!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!